 <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank"></a> 2022</p>
                </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************--><?php /**PATH C:\xampp\htdocs\aap-admin\resources\views/partials/footer.blade.php ENDPATH**/ ?>