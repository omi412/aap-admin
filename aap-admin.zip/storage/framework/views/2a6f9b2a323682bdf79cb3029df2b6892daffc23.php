<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>AAP</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset ('assets/images/aap_logo.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset ('assets/vendor/owl-carousel/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset ('assets/vendor/owl-carousel/css/owl.theme.default.min.css')); ?>">
    <link href="<?php echo e(asset ('assets/vendor/jqvmap/css/jqvmap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('assets/css/custom.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />


</head>

<body>
     <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php echo $__env->make('partials/headers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <?php echo $__env->make('partials/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <!-- <?php $__env->startSection('content'); ?> -->
        <div class="content-body">
            <!-- row -->
            <div class="container-fluid">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        <?php echo $__env->make('partials/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>


    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
     <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="<?php echo e(asset ('assets/vendor/global/global.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('assets/js/quixnav-init.js')); ?>"></script>
    <script src="<?php echo e(asset ('assets/js/custom.min.js')); ?>"></script>


    <!-- Vectormap -->
    <script src="<?php echo e(asset ('assets/vendor/raphael/raphael.min.js')); ?>"></script>
    <!-- <script src="<?php echo e(asset ('assets/vendor/morris/morris.min.js')); ?>"></script> -->


    <script src="<?php echo e(asset ('assets/vendor/circle-progress/circle-progress.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('assets/vendor/chart.js/Chart.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset ('assets/vendor/gaugeJS/dist/gauge.min.js')); ?>"></script>

    <!--  flot-chart js -->
    <script src="<?php echo e(asset ('assets/vendor/flot/jquery.flot.js')); ?>"></script>
    <script src="<?php echo e(asset ('assets/vendor/flot/jquery.flot.resize.js')); ?>"></script>

    <!-- Owl Carousel -->
    <script src="<?php echo e(asset ('assets/vendor/owl-carousel/js/owl.carousel.min.js')); ?>"></script>

    <!-- Counter Up -->
    <script src="<?php echo e(asset ('assets/vendor/jqvmap/js/jquery.vmap.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('assets/vendor/jqvmap/js/jquery.vmap.usa.js')); ?>"></script>
    <script src="<?php echo e(asset ('assets/vendor/jquery.counterup/jquery.counterup.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>

   <!--  <script src="<?php echo e(asset ('assets/js/dashboard/dashboard-1.js')); ?>"></script> -->

    <?php echo $__env->yieldContent('script'); ?>


</body>

</html>
<?php /**PATH C:\xampp\htdocs\aap-admin\resources\views/layouts/master.blade.php ENDPATH**/ ?>