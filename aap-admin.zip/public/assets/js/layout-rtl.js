(function($) {
    "use strict"

    new quixSettings({
        direction: "rtl"
    });


})(jQuery);